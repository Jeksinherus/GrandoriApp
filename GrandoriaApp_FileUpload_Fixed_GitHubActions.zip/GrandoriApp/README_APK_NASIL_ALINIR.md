# Grandori APK alma rehberi - telefondan

Bu proje GitHub Actions ile otomatik APK üretir.

## 1) GitHub hesabına gir
Telefondan github.com adresine gir ve giriş yap.

## 2) Yeni repository aç
- Sağ üstten + butonuna bas
- New repository seç
- Repository name: GrandoriApp
- Public veya Private seçebilirsin
- Create repository de

## 3) ZIP içindeki dosyaları yükle
- Açılan repository sayfasında Add file > Upload files seç
- Bu ZIP'in içindeki GrandoriApp klasörünün içeriğini yükle
- `.github` klasörü de mutlaka yüklensin
- Commit changes de

## 4) APK oluştur
- Repository içinde Actions sekmesine gir
- Build Grandori APK seç
- Run workflow butonuna bas
- 2-5 dakika bekle

## 5) APK indir
- İşlem bitince yeşil tikli build'e gir
- En altta Artifacts bölümünde Grandori-debug-apk dosyasını indir
- ZIP olarak iner, açınca app-debug.apk çıkar
- APK'yı telefona kur

## Not
Bu debug APK'dır. Telefona kurulur. Play Store'a yüklemek için release imzalı APK/AAB gerekir.
